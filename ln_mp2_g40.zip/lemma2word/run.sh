#!/bin/bash

test=false
clean=false
draw=false
verbose=false
default_test="lavar+V+if+2s"
flags=""

HIGHLIGHT='\033[1;33m'
NC='\033[0m' # No Color

print_usage() {
  printf "Usage: -c for cleanup, -v for verbose, -d for draws and -t for testing (or -T [FILENAME] to overwrite default test)\n"
}

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

while getopts 'T:tcvd' flag; do
  case "${flag}" in
    T) default_test="${OPTARG}"
		test=true
		flags=$flags" -t";;
	t) test=true
		flags=$flags" -t";;
    c) clean=true ;;
    v) verbose=true
		flags=$flags" -v";;
    d) draw=true
		flags=$flags" -d";;
    *) print_usage
		exit 1 ;;
  esac
done

if [ "$clean" = true ] 
then	
	###################    Cleanup   ################
	rm -f *.fst *.pdf
	rm -f test.txt
	("../read_word/run.sh" -c)
	("lemma2noun/run.sh" -c)
	("lemma2adverb/run.sh" -c)
	("lemma2verb/run.sh" -c)

else
	################### lemma2verb ################
	if [ "$verbose" = true ] 
	then
		printf "\nCompiling lemma2word...\n"
	fi
	("../read_word/run.sh")
	("lemma2noun/run.sh" $flags)
	("lemma2adverb/run.sh" $flags)
	("lemma2verb/run.sh" $flags)

	fstunion lemma2noun/tags2noun_sufix.fst lemma2adverb/tags2adverb_sufix.fst > tags2word_sufix.fst
	fstunion tags2word_sufix.fst lemma2verb/tags2verb_sufix.fst > aux_tags2word_sufix.fst

	fstrmepsilon aux_tags2word_sufix.fst | fstdeterminize | fstminimize > tags2word_sufix.fst

	fstconcat ../read_word/read_word.fst tags2word_sufix.fst | fstrmepsilon > lemma2word.fst

	if [ "$draw" = true ] 
	then
		if [ "$verbose" = true ] 
		then
			printf "Drawing lemma2word...\n"
		fi
		fstdraw    --isymbols=../syms.txt --osymbols=../syms.txt --portrait tags2word_sufix.fst | dot -Tpdf  > tags2word_sufix.pdf
		fstdraw    --isymbols=../syms.txt --osymbols=../syms.txt --portrait lemma2word.fst | dot -Tpdf  > lemma2word.pdf
	fi

	###################    Test     ################
	if [ "$test" = true ] 
	then	
		if [ "$verbose" = true ] 
		then
			printf "Testing lemma2word with \"${HIGHLIGHT}${default_test}${NC}\"...\n"
		fi
		python3 ../scripts/word2fst.py -s ../syms.txt $default_test > test.txt
		fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  test.txt | fstarcsort > test.fst
		fstcompose test.fst lemma2word.fst > result.fst
		if [ "$draw" = true ] 
		then
			fstdraw --isymbols=../syms.txt --osymbols=../syms.txt --portrait result.fst | dot -Tpdf > result.pdf
		fi

		if [ "$verbose" = true ] 
		then
			printf "Results:\n"
			fstrmepsilon result.fst | fsttopsort | fstprint --isymbols=../syms.txt --osymbols=../syms.txt
		fi
	fi
fi