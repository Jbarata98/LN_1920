#!/bin/bash

clean=false
draw=false
debug=false

HIGHLIGHT='\033[1;33m'
NC='\033[0m' # No Color

print_usage() {
  printf "Usage: -c for cleanup, -D for debug and -d for draw\n"
}

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

while getopts 'cdD' flag; do
  case "${flag}" in
    c) clean=true ;;
    d) draw=true ;;
    D) debug=true ;;
    *) print_usage
		exit 1 ;;
  esac
done

shift $((OPTIND-1))

if [ "$clean" = true ] 
then	
	###################    Cleanup   ################
	rm -f *.fst *.pdf *.txt
else
	if ! [ "$@" ]
	then
		echo "refer the file.txt with the words to transduce"
	fi

	{
	IFS=$'\t' read -r -a myArray
	python3 word2fst.py -s ../syms.txt -r "${myArray[1]}" "${myArray[0]}" > replacer.txt
	fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  replacer.txt | fstarcsort > replacer.fst

	if [ "$debug" = true ] 
	then
		echo "DEBUG: ${myArray[0]} to ${myArray[1]}" >> debug.txt
		cat replacer.txt >> debug.txt
	fi

	while IFS=$'\t' read -r -a myArray
	do
		python3 word2fst.py -s ../syms.txt -r "${myArray[1]}" "${myArray[0]}" > replacer.txt
		fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  replacer.txt | fstarcsort > mono_replacer.fst
		fstunion replacer.fst mono_replacer.fst > result.fst
		mv result.fst replacer.fst

		if [ "$debug" = true ] 
		then
			echo "DEBUG: ${myArray[0]} to ${myArray[1]}" >> debug.txt
			cat replacer.txt >> debug.txt
		fi
	done 
	} < $@
	
	fstrmepsilon replacer.fst | fstdeterminize | fstminimize > s_replacer.fst
	fstprint --isymbols=../syms.txt --osymbols=../syms.txt s_replacer.fst
	
	if [ "$draw" = true ] 
	then
		fstdraw    --isymbols=../syms.txt --osymbols=../syms.txt --portrait s_replacer.fst | dot -Tpdf  > replacer.pdf
	fi
fi