#!env python3
import argparse
import csv
import re

if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description="Converts a word into an FST")
    PARSER.add_argument("-s", dest="symbols", default=None, help="file containing the symbols")
    PARSER.add_argument("-r", dest="r_word", default=None, help="word to replace the latter (\"?\" for empty)")
    PARSER.add_argument('word', help='a word')
    args = PARSER.parse_args()

    if not args.symbols:
        # processes character by character
        if not args.r_word:
            for i, c in enumerate(args.word):
                print("%d %d %s %s" % (i, i + 1, c, c))
            print(i + 1)
        else:
            word, r_word = args.word, args.r_word if args.r_word != "?" else ""
            for i in range(max(len(word), len(r_word))):
                c, r = word[i] if i < len(word) else "esp", r_word[i] if i < len(r_word) else "esp"
                print("%d %d %s %s" % (i, i + 1, c, r))
            print(i + 1)
    else:
        if not args.r_word:
            with open(args.symbols, encoding="utf-8") as f:
                symbols = [row.split()[0] for row in f if row.split()[0] != "eps"]
                symbols.sort(key=lambda s: len(s), reverse=True)
                tmp = re.sub("\+", "\+", "|".join(symbols))
                # print(tmp.encode("utf-8"))
                exp = re.compile(tmp)

            word = args.word
            m = exp.match(word)
            i = 0
            while (len(word) > 0) and (m is not None):
                print("%d %d %s %s" % (i, i + 1, m.group(), m.group()))
                word = word[m.end():]
                m = exp.match(word)
                i += 1
            if len(word) > 0:
                print("unknown symbols in expression: ", word)
            else:
                print(i)
        else:
            with open(args.symbols, encoding="utf-8") as f:
                symbols = [row.split()[0] for row in f if row.split()[0] != "eps"]
                symbols.sort(key=lambda s: len(s), reverse=True)
                tmp = re.sub("\+", "\+", "|".join(symbols))
                # print(tmp.encode("utf-8"))
                exp = re.compile(tmp)

            word, r_word = args.word, args.r_word if args.r_word != "?" else ""
            m, r = exp.match(word), exp.match(r_word)
            i = 0
            while (len(word) > 0) and (m is not None) or (len(r_word) > 0) and (r is not None):
                m_print, r_print = m.group() if m is not None else "eps", r.group() if r is not None else "eps"
                print("%d %d %s %s" % (i, i + 1, m_print, r_print))
                if len(word) > 0:
                    word = word[m.end():]
                    m = exp.match(word)
                if len(r_word) > 0:
                    r_word = r_word[r.end():]
                    r = exp.match(r_word)
                i += 1
            if (len(word) > 0) or (len(r_word) > 0):
                print("unknown symbols in expression: ", word)
            else:
                print(i)
