#!/bin/bash

clean=false
draw=false
verbose=false
default_tests="default.txt"
examples=("lemma2verb" "lemma2word" "word2lemma")

HIGHLIGHT='\033[1;33m'
NC='\033[0m' # No Color

print_usage() {
  printf "Usage: -c for cleanup, -v for verbose, -d to draw and -T [FILENAME] to overwrite default tests\n"
}

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

while getopts 'T:tcvd' flag; do
  case "${flag}" in
    T) default_test="${OPTARG}" ;;
    c) clean=true ;;
    v) verbose=true ;;
    d) draw=true ;;
    *) print_usage
		exit 1 ;;
  esac
done

if [ "$clean" = true ] 
then	
	###################    Cleanup   ################
	rm -f *.fst *.pdf
	rm -rf "${examples[0]}/"*
	rm -rf "${examples[1]}/"*
	rm -rf "${examples[2]}/"*
	rm -f test.txt

else
	################### lemma2verb ################

	if [ "$verbose" = true ] 
	then
		printf "\nCompiling tests...\n\n"
	fi

	ex=0
	while IFS=$'\t' read -r -a tests
	do
		for (( i=0; i < ${#tests[@]}; ++i ))
		do
			python3 ../scripts/word2fst.py -s ../syms.txt "${tests[$i]}" > "test.txt"
			if [ "$verbose" = true ] 
			then
				printf "Compiling ${examples[$ex]}/test${i}.fst...\n"
			fi
			fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  test.txt | fstarcsort > "${examples[$ex]}/test${i}.fst"
			if [ "$draw" = true ] 
			then
				if [ "$verbose" = true ] 
				then
					printf "Drawing ${examples[$ex]}/test${i}.fst...\n"
				fi
				fstdraw    --isymbols=../syms.txt --osymbols=../syms.txt --portrait "${examples[$ex]}/test${i}.fst" | dot -Tpdf  > "${examples[$ex]}/test${i}.pdf"
			fi
		done
	((ex++))
	done < $default_tests

fi