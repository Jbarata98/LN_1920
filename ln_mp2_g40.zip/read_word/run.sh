#!/bin/bash

test=false
clean=false
draw=false
verbose=false
default_test="palavra"


print_usage() {
  printf "Usage: -c for cleanup, -v for verbose, -d for draws and -t for testing (or -T [WORD] to overwrite default test)\n"
}

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

while getopts 'T:tcvd' flag; do
  case "${flag}" in
    T) default_test="${OPTARG}"
		test=true;;
	t) test=true;;
    c) clean=true ;;
    v) verbose=true ;;
    d) draw=true ;;
    *) print_usage
		exit 1 ;;
  esac
done

if [ "$clean" = true ] 
then	
	###################   Cleanup  ################
	rm -f *.fst *.pdf
	rm -f test.txt
else
	################### read_word  ################
	fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  read_word.txt | fstarcsort > read_word.fst
	if [ "$draw" = true ] 
	then
		fstdraw --isymbols=../syms.txt --osymbols=../syms.txt --portrait read_word.fst | dot -Tpdf  > read_word.pdf
	fi

	###################    Test    ################
	if [ "$test" = true ] 
	then	
		python3 ../scripts/word2fst.py $default_test > test.txt
		fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  test.txt | fstarcsort > test.fst
		fstcompose test.fst read_word.fst > result.fst
		if [ "$draw" = true ] 
		then
			fstdraw --isymbols=../syms.txt --osymbols=../syms.txt --portrait result.fst | dot -Tpdf > result.pdf
		fi

		if [ "$verbose" = true ] 
		then
			fstrmepsilon result.fst | fsttopsort | fstprint --isymbols=../syms.txt --osymbols=../syms.txt
		fi
	fi
fi