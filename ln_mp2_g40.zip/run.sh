#!/bin/bash

test=true
clean=false
draw=true
verbose=false
flags=""
examples=("lemma2verb" "lemma2word" "word2lemma")


print_usage() {
  printf "Usage: -c for cleanup, -v for verbose, -d to prevent drawing and -t to prevent testing\n"
}

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

while getopts 'T:tcvd' flag; do
  case "${flag}" in
    t) test=false ;;
    c) clean=true ;;
    v) verbose=true
		flags=$flags" -v" ;;
    d) draw=false ;;
    *) print_usage
		exit 1 ;;
  esac
done

if [ "$clean" = true ] 
then	
	###################   Cleanup  ################
	rm -f *.fst
	rm -f test.txt
	("word2lemma/run.sh" -c)
	("FINALexamples/run.sh" -c)
	rm -rf FINALtransducers/*
	rm -rf FINALpdf/*

else
	if [ "$draw" = true ] 
	then
		flags=$flags" -d"
	fi

	if [ "$verbose" = true ] 
	then
		flags=$flags" -v"
		printf "Generating transducers:\n\n"
	fi
	("word2lemma/run.sh" $flags)

	mv lemma2word/lemma2noun/lemma2noun.fst FINALtransducers/lemma2noun.fst
	mv lemma2word/lemma2adverb/lemma2adverb.fst FINALtransducers/lemma2adverb.fst
	mv lemma2word/lemma2verb/lemma2verb.fst FINALtransducers/lemma2verb.fst
	mv lemma2word/lemma2verb/lemma2verbip/lemma2verbip.fst FINALtransducers/lemma2verbip.fst
	mv lemma2word/lemma2verb/lemma2verbis/lemma2verbis.fst FINALtransducers/lemma2verbis.fst
	mv lemma2word/lemma2verb/lemma2verbif/lemma2verbif.fst FINALtransducers/lemma2verbif.fst
	mv lemma2word/lemma2word.fst FINALtransducers/lemma2word.fst
	mv word2lemma/word2lemma.fst FINALtransducers/word2lemma.fst

	if [ "$draw" = true ] 
	then
		mv lemma2word/lemma2noun/lemma2noun.pdf FINALpdf/lemma2noun.pdf
		mv lemma2word/lemma2adverb/lemma2adverb.pdf FINALpdf/lemma2adverb.pdf
		mv lemma2word/lemma2verb/lemma2verb.pdf FINALpdf/lemma2verb.pdf
		mv lemma2word/lemma2verb/lemma2verbip/lemma2verbip.pdf FINALpdf/lemma2verbip.pdf
		mv lemma2word/lemma2verb/lemma2verbis/lemma2verbis.pdf FINALpdf/lemma2verbis.pdf
		mv lemma2word/lemma2verb/lemma2verbif/lemma2verbif.pdf FINALpdf/lemma2verbif.pdf
		mv lemma2word/lemma2word.pdf FINALpdf/lemma2word.pdf
		mv word2lemma/word2lemma.pdf FINALpdf/word2lemma.pdf
	fi

	("FINALexamples/run.sh" $flags)

	for (( i=0; i < ${#examples[@]}; ++i ))
	do
		for testPath in FINALexamples/"${examples[i]}"/*.fst
		do
		    [ -f "$testPath" ] || break
			testFile=$(basename -- "$testPath")
			test="${testFile%.*}"
			if [ "$verbose" = true ] 
			then
				printf "Testing ${examples[i]} with ${test}...\n"
			fi
			fstcompose "${testPath}" FINALtransducers/"${examples[i]}".fst > result.fst
			if [ "$draw" = true ] 
			then
				if [ "$verbose" = true ] 
				then
					printf "Drawing result of ${examples[i]} with ${test}...\n"
					fstrmepsilon result.fst | fsttopsort | fstprint --isymbols=syms.txt --osymbols=syms.txt
				fi
				fstdraw    --isymbols=syms.txt --osymbols=syms.txt --portrait result.fst | dot -Tpdf  > FINALexamples/"${test}_${examples[i]}".pdf
			fi
			mv result.fst FINALexamples/"${test}_${examples[i]}".fst
		done
	done

fi
