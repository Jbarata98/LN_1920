#!/bin/bash

test=false
clean=false
draw=false
verbose=false
default_test="alunos"
flags=""

HIGHLIGHT='\033[1;33m'
NC='\033[0m' # No Color

print_usage() {
  printf "Usage: -c for cleanup, -v for verbose, -d for draws and -t for testing (or -T [WORD+TAG] to overwrite default test)\n"
}

parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )

cd "$parent_path"

while getopts 'T:tcvd' flag; do
  case "${flag}" in
    T) default_test="${OPTARG}"
		test=true
		flags=$flags" -t";;
	t) test=true
		flags=$flags" -t";;
    c) clean=true ;;
    v) verbose=true
		flags=$flags" -v";;
    d) draw=true
		flags=$flags" -d";;
    *) print_usage
		exit 1 ;;
  esac
done

if [ "$clean" = true ] 
then	
	###################    Cleanup   ################
	rm -f *.fst *.pdf
	rm -f test.txt
	("../lemma2word/run.sh" -c)

else
	################### lemma2verb ################
	if [ "$verbose" = true ] 
	then
		printf "\nCompiling word2lemma...\n"
	fi
	("../lemma2word/run.sh" $flags)

	fstinvert ../lemma2word/lemma2word.fst > word2lemma.fst

	if [ "$draw" = true ] 
	then
		if [ "$verbose" = true ] 
		then
			printf "Drawing word2lemma...\n"
		fi
		fstdraw    --isymbols=../syms.txt --osymbols=../syms.txt --portrait word2lemma.fst | dot -Tpdf  > word2lemma.pdf
	fi

	###################    Test     ################
	if [ "$test" = true ] 
	then	
		if [ "$verbose" = true ] 
		then
			printf "Testing word2lemma with \"${HIGHLIGHT}${default_test}${NC}\"...\n"
		fi
		python3 ../scripts/word2fst.py -s ../syms.txt $default_test > test.txt
		fstcompile --isymbols=../syms.txt --osymbols=../syms.txt  test.txt | fstarcsort > test.fst
		fstcompose test.fst word2lemma.fst > result.fst
		if [ "$draw" = true ] 
		then
			fstdraw --isymbols=../syms.txt --osymbols=../syms.txt --portrait result.fst | dot -Tpdf > result.pdf
		fi

		if [ "$verbose" = true ] 
		then
			printf "Results:\n"
			fstrmepsilon result.fst | fsttopsort | fstprint --isymbols=../syms.txt --osymbols=../syms.txt
		fi
	fi
fi